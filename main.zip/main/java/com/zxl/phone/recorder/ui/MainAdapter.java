package com.zxl.phone.recorder.ui;

import android.app.usage.UsageEvents;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.zxl.phone.recorder.R;
import com.zxl.phone.recorder.room.AnalyzeEventData;
import com.zxl.phone.recorder.room.EventData;
import com.zxl.phone.recorder.utils.ConvertUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.CustomHolder> {
    private static final String TAG = "MainAdapter";

    private List<AnalyzeEventData> dataList = new ArrayList<>();

    public void setData(List<AnalyzeEventData> list) {
        dataList.clear();
        dataList.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CustomHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.main_item_view, parent, false);
        return new CustomHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomHolder holder, int position) {
        AnalyzeEventData eventData = dataList.get(position);

        try {
            PackageManager pm = holder.itemImg.getContext().getPackageManager();
            holder.itemImg.setImageDrawable(pm.getApplicationInfo(eventData.packageName, PackageManager.GET_META_DATA).loadIcon(pm));
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        String content = ""/*ConvertUtils.convertTimeStr(eventData.eventTime)*/;
        if (TextUtils.isEmpty(eventData.appName)) {
            content = content/* + "---"*/ + eventData.packageName;
        } else {
            content = content/* + "---"*/ + eventData.appName;
        }
        content = content + "---" + ConvertUtils.convertDurationStr(eventData.consumingTime);
        holder.itemTv.setText(content);
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    class CustomHolder extends RecyclerView.ViewHolder {
        public ImageView itemImg;
        public TextView itemTv;

        public CustomHolder(@NonNull View itemView) {
            super(itemView);
            itemImg = itemView.findViewById(R.id.main_item_img);
            itemTv = itemView.findViewById(R.id.main_item_tv);
        }
    }
}
