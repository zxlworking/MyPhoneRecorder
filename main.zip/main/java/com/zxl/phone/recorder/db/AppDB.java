package com.zxl.phone.recorder.db;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.zxl.phone.recorder.dao.EventDataDao;
import com.zxl.phone.recorder.room.EventData;

@Database(entities = {EventData.class}, version = 1)
public abstract class AppDB extends RoomDatabase {
    private static final String TAG = "AppDB";

    private static AppDB mAppDB;
    private static Object mLock = new Object();

    public abstract EventDataDao getEventDataDao();

    public static AppDB getInstance(Context context) {
        if (mAppDB == null) {
            synchronized (mLock) {
                if (mAppDB == null) {
                    mAppDB = buildDB(context);
                }
            }
        }
        return mAppDB;
    }

    private static AppDB buildDB(Context context) {
        return Room.databaseBuilder(context, AppDB.class, "jetPackDemo-database")
                .addCallback(new Callback() {
                    @Override
                    public void onCreate(@NonNull SupportSQLiteDatabase db) {
                        super.onCreate(db);
                        Log.i(TAG, "buildDB::onCreate");
                    }
                }).build();
    }
}
