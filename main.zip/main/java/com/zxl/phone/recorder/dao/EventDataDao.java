package com.zxl.phone.recorder.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.zxl.phone.recorder.room.EventData;

import java.util.List;

@Dao
public interface EventDataDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertEvent(EventData eventData);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertEvent(List<EventData> list);

    @Query("SELECT * FROM event_data")
    public LiveData<List<EventData>> getAllEventData();

    @Query("SELECT * FROM event_data ORDER BY id DESC")
    public List<EventData> getAllEventDataDesc();

    @Query("SELECT * FROM event_data WHERE :beginTime < event_time AND event_time < :endTime")
    public LiveData<List<EventData>> getAllEventDataByTimeRange(long beginTime, long endTime);
}
