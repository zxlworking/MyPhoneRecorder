package com.zxl.phone.recorder.room;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.zxl.phone.recorder.utils.ConvertUtils;

@Entity(tableName = "event_data")
public class EventData {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    public long id = 0;

    @ColumnInfo(name = "app_name")
    public String appName = "";
    @ColumnInfo(name = "package_name")
    public String packageName = "";
    @ColumnInfo(name = "class_name")
    public String className = "";
    @ColumnInfo(name = "event_type")
    public int eventType = -1;
    @ColumnInfo(name = "event_time")
    public long eventTime = 0;

    @Override
    public String toString() {
        return "EventData{" +
                "id=" + id +
                ", appName='" + appName + '\'' +
                ", packageName='" + packageName + '\'' +
                ", className='" + className + '\'' +
                ", eventType=" + eventType +
                ", eventTime=" + ConvertUtils.convertTimeStr(eventTime) +
                '}';
    }
}
