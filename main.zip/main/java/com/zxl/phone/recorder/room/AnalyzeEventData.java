package com.zxl.phone.recorder.room;

public class AnalyzeEventData extends EventData{
    public long consumingTime = 0;
}
