package com.zxl.phone.recorder.worker;

import android.app.ActivityManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.zxl.phone.recorder.db.AppDB;
import com.zxl.phone.recorder.repository.EventRepository;
import com.zxl.phone.recorder.room.EventData;
import com.zxl.phone.recorder.utils.ConvertUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class EventRecordWorker extends Worker {
    private static final String TAG = "RecorderWorker";

    private static Object lock = new Object();

    private static boolean isRecording = false;
    private static long beginTime = 0;

    public EventRecordWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        synchronized (lock) {
            if (isRecording) {
                Log.i(TAG, "doWork::newEventDataList isRecording");
                return Result.success(new Data.Builder().putBoolean("isRecording", true).build());
            }
            isRecording = true;
            List<EventData> lastEventDataList = AppDB.getInstance(getApplicationContext()).getEventDataDao().getAllEventDataDesc();
            long lastTime = 0;
            if (lastEventDataList != null && lastEventDataList.size() > 0) {
                EventData lastEventData = lastEventDataList.get(0);
                Log.i(TAG, "doWork::lastEventData = " + lastEventData);
                lastTime = lastEventData.eventTime;
            }

            List<EventData> newEventDataList = getPhoneRecordInfo(getApplicationContext(), lastTime);
            Log.i(TAG, "doWork::newEventDataList = " + newEventDataList);
            AppDB.getInstance(getApplicationContext()).getEventDataDao().insertEvent(newEventDataList);
            Log.i(TAG, "doWork::newEventDataList finish");
            isRecording = false;
            return Result.success(new Data.Builder().putBoolean("recordFinish", true).build());
        }
    }

    private List<EventData> getPhoneRecordInfo(Context context, long lastTime) {
        Log.i(TAG, "doWork::getPhoneRecordInfo::" + ConvertUtils.convertTimeStr(beginTime));
        List<EventData> eventDataList = new ArrayList<>();

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            /*List<ActivityManager.RunningTaskInfo> appTasks = activityManager.getRunningTasks(1);
            if (null != appTasks && !appTasks.isEmpty()) {
                return appTasks.get(0).topActivity.getPackageName();
            }*/
        } else {
            //5.0以后需要用这方法
            PackageManager packageManager = getApplicationContext().getPackageManager();

            /*List<ApplicationInfo> listAppcations = packageManager.getInstalledApplications(PackageManager.GET_UNINSTALLED_PACKAGES);
            for (ApplicationInfo applicationInfo : listAppcations) {
                Log.i(TAG, "doWork::applicationInfo--->"+applicationInfo.loadLabel(packageManager));
            }*/

            long endTime = System.currentTimeMillis();
            if (beginTime == 0) {
                beginTime = endTime - 1000 * 60 * 30;
            }
            UsageStatsManager manager = (UsageStatsManager) context.getSystemService(Context.USAGE_STATS_SERVICE);
            UsageEvents usageEvents = manager.queryEvents(beginTime, endTime);

            UsageEvents.Event eventOut;
            while (usageEvents.hasNextEvent()) {
                eventOut = new UsageEvents.Event();
                usageEvents.getNextEvent(eventOut);

                if (eventOut.getTimeStamp() > lastTime) {
                    String packageName = eventOut.getPackageName();
                    String className = eventOut.getClassName();
                    int eventType = eventOut.getEventType();
    //        int standbyBucket = event.getAppStandbyBucket();
    //        String shortcutId = event.getShortcutId();
                    String time = ConvertUtils.convertTimeStr(eventOut.getTimeStamp());

                    Log.i(TAG, "| " + packageName + " | " + className + " | " + eventType /*+ " | " + standbyBucket + " | " + shortcutId*/ + " | " + time + " |");

                    EventData eventData = new EventData();
                    try {
                        int labelRes = packageManager.getApplicationInfo(packageName, PackageManager.GET_META_DATA).labelRes;
                        eventData.appName = context.getResources().getString(labelRes);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    eventData.packageName = packageName;
                    eventData.className = className;
                    eventData.eventType = eventType;
                    eventData.eventTime = eventOut.getTimeStamp();

                    eventDataList.add(eventData);
                }
            }

            beginTime = endTime;
        }
        return eventDataList;
    }
}
