package com.zxl.phone.recorder.utils;

import android.app.usage.UsageEvents;

import com.zxl.phone.recorder.room.EventData;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ConvertUtils {
    public static String convertTimeStr(long t) {
        DateFormat format = new SimpleDateFormat("yyyy.MM.dd_HH:mm:ss", Locale.getDefault());
        String timeStr = format.format(new Date(t));
        return timeStr;
    }

    public static String convertDurationStr(long t) {
        String s = "";
        t = t / 1000;
        if (t >= 3600) {
            s = s + (t / 3600) + "小时";
            t = t % 3600;
        }
        if (t >= 60) {
            s = s + (t / 60) + "分钟";
            t = t % 60;
        }
        s = s + t + "秒";
        return s;
    }

    public static Date convertStrTime(String str) {
        Date date = null;
        try {
            DateFormat format = new SimpleDateFormat("yyyy.MM.dd_HH:mm:ss", Locale.getDefault());
            date = format.parse(str);
        } catch (Exception e) {
            e.printStackTrace();
            try {
                DateFormat format = new SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault());
                date = format.parse(str);
            } catch (Exception parseException) {
                parseException.printStackTrace();
            }
        }
        return date;
    }

    public static String convertEventTypeStr(int type) {
        String eventTypeStr = "";
        switch (type) {
            case UsageEvents.Event.NONE:
                eventTypeStr = "NONE";
                break;
            //case UsageEvents.Event.MOVE_TO_FOREGROUND:
            case UsageEvents.Event.ACTIVITY_RESUMED:
                eventTypeStr = "ACTIVITY_RESUMED";
                break;
            //case UsageEvents.Event.MOVE_TO_BACKGROUND:
            case UsageEvents.Event.ACTIVITY_PAUSED:
                eventTypeStr = "ACTIVITY_PAUSED";
                break;
            case 3:
                eventTypeStr = "END_OF_DAY";
                break;
            case 4:
                eventTypeStr = "CONTINUE_PREVIOUS_DAY";
                break;
            case UsageEvents.Event.CONFIGURATION_CHANGE:
                eventTypeStr = "CONFIGURATION_CHANGE";
                break;
            case 6:
                eventTypeStr = "SYSTEM_INTERACTION";
                break;
            case UsageEvents.Event.USER_INTERACTION:
                eventTypeStr = "USER_INTERACTION";
                break;
            case UsageEvents.Event.SHORTCUT_INVOCATION:
                eventTypeStr = "SHORTCUT_INVOCATION";
                break;
            case 9:
                eventTypeStr = "CHOOSER_ACTION";
                break;
            case 10:
                eventTypeStr = "NOTIFICATION_SEEN";
                break;
            case UsageEvents.Event.STANDBY_BUCKET_CHANGED:
                eventTypeStr = "STANDBY_BUCKET_CHANGED";
                break;
            case 12:
                eventTypeStr = "NOTIFICATION_INTERRUPTION";
                break;
            case 13:
                eventTypeStr = "SLICE_PINNED_PRIV";
                break;
            case 14:
                eventTypeStr = "SLICE_PINNED";
                break;
            case UsageEvents.Event.SCREEN_INTERACTIVE:
                eventTypeStr = "SCREEN_INTERACTIVE";
                break;
            case UsageEvents.Event.SCREEN_NON_INTERACTIVE:
                eventTypeStr = "SCREEN_NON_INTERACTIVE";
                break;
            case UsageEvents.Event.KEYGUARD_SHOWN:
                eventTypeStr = "KEYGUARD_SHOWN";
                break;
            case UsageEvents.Event.KEYGUARD_HIDDEN:
                eventTypeStr = "KEYGUARD_HIDDEN";
                break;
            case UsageEvents.Event.FOREGROUND_SERVICE_START:
                eventTypeStr = "FOREGROUND_SERVICE_START";
                break;
            case UsageEvents.Event.FOREGROUND_SERVICE_STOP:
                eventTypeStr = "FOREGROUND_SERVICE_STOP";
                break;
            case 21:
                eventTypeStr = "CONTINUING_FOREGROUND_SERVICE";
                break;
            case 22:
                eventTypeStr = "ROLLOVER_FOREGROUND_SERVICE";
                break;
            case UsageEvents.Event.ACTIVITY_STOPPED:
                eventTypeStr = "ACTIVITY_STOPPED";
                break;
            case 24:
                eventTypeStr = "ACTIVITY_DESTROYED";
                break;
            case 25:
                eventTypeStr = "FLUSH_TO_DISK";
                break;
            case UsageEvents.Event.DEVICE_SHUTDOWN:
                eventTypeStr = "DEVICE_SHUTDOWN";
                break;
            case UsageEvents.Event.DEVICE_STARTUP:
                eventTypeStr = "DEVICE_STARTUP";
                break;
            case 28:
                eventTypeStr = "USER_UNLOCKED";
                break;
            case 29:
                eventTypeStr = "USER_STOPPED";
                break;
            case 30:
                eventTypeStr = "LOCUS_ID_SET";
                break;
            case 31:
                eventTypeStr = "APP_COMPONENT_USED";
                break;
        }
        return eventTypeStr;
    }
}
