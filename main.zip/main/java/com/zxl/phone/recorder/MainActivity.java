package com.zxl.phone.recorder;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.work.Data;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.text.format.Formatter;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.zxl.phone.recorder.db.AppDB;
import com.zxl.phone.recorder.repository.EventRepository;
import com.zxl.phone.recorder.room.AnalyzeEventData;
import com.zxl.phone.recorder.room.EventData;
import com.zxl.phone.recorder.ui.MainAdapter;
import com.zxl.phone.recorder.utils.ConvertUtils;
import com.zxl.phone.recorder.utils.TimesUtils;
import com.zxl.phone.recorder.worker.EventRecordWorker;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    private EditText dateEditTv;
    private Button confirmBtn;

    private RecyclerView recyclerView;
    private MainAdapter mainAdapter;

    private ImageView mImg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dateEditTv = findViewById(R.id.date_edit_tv);
        confirmBtn = findViewById(R.id.confirm_btn);
        mImg = findViewById(R.id.img);

        dateEditTv.setText(ConvertUtils.convertTimeStr(System.currentTimeMillis()));

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        mainAdapter = new MainAdapter();
        recyclerView.setAdapter(mainAdapter);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //startForegroundService(new Intent(this, RecorderService.class));
        }

//        if (!isStatAccessPermissionSet(this)) {
//            Log.i(TAG, "no AccessPermission");
//            //startActionUsageAccessSettings(this);
//        }

//        PeriodicWorkRequest workRequest = new PeriodicWorkRequest.Builder(EventRecordWorker.class, 15, TimeUnit.MINUTES)
//                .setInputData(new Data.Builder().putLong("begin_time", 0L).build())
//                .build();
//        WorkManager.getInstance(this.getApplicationContext()).enqueue(workRequest);
//
//        AppDB.getInstance(this).getEventDataDao().getAllEventData().observe(this, new Observer<List<EventData>>() {
//            @Override
//            public void onChanged(List<EventData> eventData) {
//
//            }
//        });
//
//        WorkManager.getInstance(this.getApplicationContext()).getWorkInfoByIdLiveData(workRequest.getId()).observe(this, new Observer<WorkInfo>() {
//            @Override
//            public void onChanged(WorkInfo workInfo) {
//                Log.i(TAG, "workRequest::onChanged::workInfo = " + workInfo);
//
//                Log.i(TAG, "workRequest::onChanged::dateEditTv = " + dateEditTv.getText());
//                Date date = ConvertUtils.convertStrTime(dateEditTv.getText().toString());
//
//                if (date != null) {
//                    LiveData<List<EventData>> eventDataList = EventRepository.getInstance(getApplicationContext()).getAllEventDataByTimeRange(TimesUtils.getStartTime(date).getTime(), TimesUtils.getEndTime(date).getTime());
//                    Log.i(TAG, "eventDataList = " + eventDataList);
//                    eventDataList.observe(MainActivity.this, new Observer<List<EventData>>() {
//                        @Override
//                        public void onChanged(List<EventData> eventData) {
//                            Log.i(TAG, "eventData = " + eventData);
//
//                            Map<String, EventData> dataMap = new HashMap<>();
//                            for (EventData data : eventData) {
//                                dataMap.put(data.packageName, data);
//                            }
//
//                            List<AnalyzeEventData> newDataList = new ArrayList<>();
//                            Set<String> keys = dataMap.keySet();
//                            for (String pkgName : keys) {
//                                long openTotalTime = 0;
//                                long onceOpenTime = 0;
//                                for (EventData data : eventData) {
//                                    if (TextUtils.equals(pkgName, data.packageName)) {
//                                        if (data.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
//                                            if (onceOpenTime == 0) {
//                                                onceOpenTime = data.eventTime;
//                                            }
//                                            Log.i(TAG, "ACTIVITY_RESUMED = " + data);
//                                        }
//                                        if (data.eventType == UsageEvents.Event.ACTIVITY_PAUSED) {
//                                            openTotalTime = openTotalTime + data.eventTime - onceOpenTime;
//                                            onceOpenTime = 0;
//                                            Log.i(TAG, "ACTIVITY_PAUSED = " + data + "::openTotalTime = " + openTotalTime);
//                                        }
//                                    }
//                                }
//
//                                EventData tmpData = dataMap.get(pkgName);
//                                AnalyzeEventData analyzeEventData = new AnalyzeEventData();
//                                analyzeEventData.id = tmpData.id;
//                                analyzeEventData.appName = tmpData.appName;
//                                analyzeEventData.packageName = tmpData.packageName;
//                                analyzeEventData.className = tmpData.className;
//                                analyzeEventData.eventType = tmpData.eventType;
//                                analyzeEventData.eventTime = tmpData.eventTime;
//                                analyzeEventData.consumingTime = openTotalTime;
//                                newDataList.add(analyzeEventData);
//                            }
//
//                            Collections.sort(newDataList, new Comparator<AnalyzeEventData>() {
//                                @Override
//                                public int compare(AnalyzeEventData o1, AnalyzeEventData o2) {
//                                    return o1.consumingTime < o2.consumingTime ? 1 : -1;
//                                }
//                            });
//
//                            mainAdapter.setData(newDataList);
//                        }
//                    });
//                }
//
//
//            }
//        });


        try {
            PackageManager pm = getPackageManager();
            Drawable drawable = pm.getApplicationInfo("com.xiaomi.tv.gallery", PackageManager.GET_META_DATA).loadIcon(pm);
            System.out.println("zxl--->"+drawable);
            mImg.setImageDrawable(drawable);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * 判断是否已经获取 有权查看使用情况的应用程序 权限
     *
     * @param context
     * @return
     */
    public static boolean isStatAccessPermissionSet(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            try {
                PackageManager packageManager = context.getPackageManager();
                ApplicationInfo info = packageManager.getApplicationInfo(context.getPackageName(), 0);
                AppOpsManager appOpsManager = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
                appOpsManager.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, info.uid, info.packageName);
                return appOpsManager.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, info.uid, info.packageName) == AppOpsManager.MODE_ALLOWED;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * 查看是存在查看使用情况的应用程序界面
     *
     * @return
     */
    public static boolean isNoOption(Context context) {
        PackageManager packageManager = context.getPackageManager();
        Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
        List<ResolveInfo> list = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
        return list.size() > 0;
    }

    /**
     * 转跳到 有权查看使用情况的应用程序 界面
     *
     * @param context
     */
    public static void startActionUsageAccessSettings(Context context) {
        Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }
}