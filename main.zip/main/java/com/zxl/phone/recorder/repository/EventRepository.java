package com.zxl.phone.recorder.repository;

import android.content.Context;

import androidx.lifecycle.LiveData;

import com.zxl.phone.recorder.dao.EventDataDao;
import com.zxl.phone.recorder.db.AppDB;
import com.zxl.phone.recorder.room.EventData;

import java.util.List;

public class EventRepository {

    private static EventRepository mEventRepository;
    private static Object mLock = new Object();

    private EventDataDao eventDataDao;

    public static EventRepository getInstance(Context context) {
        if (mEventRepository == null) {
            synchronized (mLock) {
                if (mEventRepository == null) {
                    mEventRepository = new EventRepository(AppDB.getInstance(context).getEventDataDao());
                }
            }
        }
        return mEventRepository;
    }

    public EventRepository(EventDataDao dao) {
        eventDataDao = dao;
    }

    public LiveData<List<EventData>> getAllEventData() {
        return eventDataDao.getAllEventData();
    }

    public List<EventData> getAllEventDataDesc() {
        return eventDataDao.getAllEventDataDesc();
    }

    public LiveData<List<EventData>> getAllEventDataByTimeRange(long beginTime, long endTime) {
        return eventDataDao.getAllEventDataByTimeRange(beginTime, endTime);
    }

    public void insertEventData(EventData data) {
        eventDataDao.insertEvent(data);
    }

    public void insertEventData(List<EventData> list) {
        eventDataDao.insertEvent(list);
    }
}
